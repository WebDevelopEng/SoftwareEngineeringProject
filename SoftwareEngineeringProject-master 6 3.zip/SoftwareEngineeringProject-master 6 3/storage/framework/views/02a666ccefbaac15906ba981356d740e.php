<?php $__env->startSection('title'); ?>
DonaCook
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo e(asset('viewcss/home.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('viewcss/css/bootstrap.css')); ?>" rel="stylesheet">
    <script src="https://kit.fontawesome.com/9e788b7c72.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body style="background-color: blanchedalmond">
    
    <div class="container-fluid mb-5" id="headlines" style="background-image: url('<?php echo e(asset('photo/salmonbeurreblanc.jpg')); ?>'); background-size: cover; background-position: center;">
        <div class="row">
            <div class="col">
                <div class="card mx-auto border-0" id="translucent-card">
                <div class="card-body">
                    <h2>DonaCook</h2>
                    <br>
                    <p style="margin-bottom: 25px;">
                    DonaCook fights hunger and reduces waste by redistributing excess food to communities in need. 
                    We also empower home cooks with delicious recipes using low-cost ingredients, making great meals accessible to all.
                    </p>
                    <button class="btn btn-explore">
                        Donate <i class="fas fa-arrow-right ms-2"></i>
                    </button>
                </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="container-fluid" id="recipes">
        <div class="row">
        <div class="col">
        <h3 class="container-title">Our Top 3 Most Iconic Recipes</h3>
        <div id="recipeCarousel" class="carousel slide w-50 mx-auto" data-bs-ride="false">
            <div class="carousel-inner">

                <div class="carousel-item active">
                    <div class="card profile-card" style="background-color:whitesmoke;">
                        <img src="<?php echo e(asset('photo/salmonbeurreblanc.jpg')); ?>" class="card-img-top" alt="Recipe 1">
                        <div class="card-body text-center">
                            <h5 class="card-title">Salmon 1</h5>
                            <p class="card-text">Description for recipe 1.</p>
                            <a href="#" class="btn btn-explore">Explore Recipe</a>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="card profile-card" style="background-color:whitesmoke;">
                        <img src="<?php echo e(asset('photo/salmonbeurreblanc.jpg')); ?>" class="card-img-top" alt="Recipe 2">
                        <div class="card-body text-center">
                            <h5 class="card-title">Recipe 2</h5>
                            <p class="card-text">Description for recipe 2.</p>
                            <a href="#" class="btn btn-explore">Explore Recipe</a>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="card profile-card" style="background-color:whitesmoke;">
                        <img src="<?php echo e(asset('photo/salmonbeurreblanc.jpg')); ?>" class="card-img-top" alt="Recipe 3">
                        <div class="card-body text-center">
                            <h5 class="card-title">Recipe 3</h5>
                            <p class="card-text">Description for recipe 3.</p>
                            <a href="#" class="btn btn-explore">Explore Recipe</a>
                        </div>
                    </div>
                </div>

            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#recipeCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#recipeCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
        </div>
        </div>
        </div>
    </div>
    <br>

    
    <div class="container my-5" id="impact-stats">
        <h3 class="text-center mb-5 fw-bold" style="color:#2c3e50">
            WE FIGHT HUNGER<br>FOR THOSE IN NEED
        </h3>
        <div class="row text-center justify-content-center">
            <div class="col-md-3 col-6 mb-4">
                <img src="<?php echo e(asset('icons/food.png')); ?>" class="stats-icon mb-3" alt="Hot Meals">
                <div class="stat-number">300.000</div>
                <div class="stat-label">Food Waste Saved</div>
            </div>
            <div class="col-md-3 col-6 mb-4">
                <img src="<?php echo e(asset('icons/volun.png')); ?>" class="stats-icon mb-3" alt="Volunteers">
                <div class="stat-number">1.000</div>
                <div class="stat-label">Volunteers</div>
            </div>
            <div class="col-md-3 col-6 mb-4">
                <img src="<?php echo e(asset('icons/people.png')); ?>" class="stats-icon mb-3" alt="Recipients">
                <div class="stat-number">70.000</div>
                <div class="stat-label">Recipients</div>
            </div>
        </div>
    </div>
    <div class="impact-side-card-container">
        <div class="impact-side-card p-4">
            <h5 class="mb-3">Why It Matters</h5>
            <p>Every year, millions go hungry while tons of food are wasted. DonaCook bridges that gap, helping both people and the planet.</p>
            <a href="<?php echo e(route('aboutus')); ?>" class="btn btn-explore mt-3">About Us</a>
        </div>
    </div>

    
    <div class="donation-banner" style="background-image: url('<?php echo e(asset('photo/donation-banner.png')); ?>');">
        <div class="overlay">
            <h2>Make a Difference Today!</h2>
            <p>Your donation can help fight hunger and reduce waste.</p>
            <a href="#" class="btn btn-explore mt-3">Donate</a>
        </div>
    </div>

    
    

    
    <div class="container my-7">
        <h3 class="container-title">DonaCook's Team</h3>
        <div class="row">
            <div class="col-md-3 col-sm-6 mb-4 card-spacing">
                <div class="card profile-card h-100">
                    <img src="<?php echo e(asset('photo/avel.jpg')); ?>" class="card-img-top" alt="Profile 1">
                    <div class="card-body text-center">
                        <h5 class="card-title">Owen Kartolo</h5>
                        <p class="card-text">1st Member</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-4 card-spacing">
                <div class="card profile-card h-100">
                    <img src="<?php echo e(asset('photo/avel.jpg')); ?>" class="card-img-top" alt="Profile 1">
                    <div class="card-body text-center">
                        <h5 class="card-title">Dionisius Avelino</h5>
                        <p class="card-text">2602117033</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-4 card-spacing">
                <div class="card profile-card h-100">
                    <img src="<?php echo e(asset('photo/avel.jpg')); ?>" class="card-img-top" alt="Profile 1">
                    <div class="card-body text-center">
                        <h5 class="card-title">Christopher Parulian Marpaung</h5>
                        <p class="card-text">3rd Member</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-4 card-spacing">
                <div class="card profile-card h-100">
                    <img src="<?php echo e(asset('photo/avel.jpg')); ?>" class="card-img-top" alt="Profile 1">
                    <div class="card-body text-center">
                        <h5 class="card-title">Tria Farissa Tsas</h5>
                        <p class="card-text">4th Member</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.headandfoot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Binus 2\Sems 6\SoftEn\SoftwareEngineeringProject\SoftwareEngineeringProject-master\resources\views/homepage.blade.php ENDPATH**/ ?>