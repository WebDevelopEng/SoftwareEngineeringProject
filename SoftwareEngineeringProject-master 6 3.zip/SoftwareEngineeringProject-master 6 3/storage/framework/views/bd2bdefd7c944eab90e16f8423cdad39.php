<?php $__env->startSection('title'); ?>
Create a Donation
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    body {
    background-color: #FFE9D2;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
}

.navbar {
    background-color: #1F2937;
    color: white;
    padding: 1rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.nav-left strong {
    font-size: 1.25rem;
    margin-right: 1rem;
}

.nav-left a, .nav-right a {
    color: white;
    margin-left: 1rem;
    text-decoration: none;
    font-weight: 500;
}

.container-centered {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 90vh;
    padding: 2rem;
}

.card-box {
    background-color: #fff;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    padding: 2rem;
    max-width: 700px;
    width: 100%;
}

.card-box h2 {
    font-size: 1.75rem;
    text-align: center;
    margin-bottom: 1.5rem;
    color: #1F2937;
    font-weight: 600;
}

label {
    display: block;
    font-weight: 500;
    color: #374151;
    margin-bottom: 0.5rem;
}

input[type="text"],
input[type="number"],
input[type="file"],
textarea {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #D1D5DB;
    border-radius: 10px;
    font-size: 1rem;
    margin-bottom: 1.25rem;
    box-sizing: border-box;
    transition: border 0.3s ease;
}

input:focus,
textarea:focus {
    outline: none;
    border-color: #1F2937;
}

button {
    background-color: #1F2937;
    color: white;
    padding: 0.75rem 2rem;
    border: none;
    border-radius: 999px;
    font-size: 1rem;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.3s ease;
    display: inline-block;
    margin-top: 1rem;
}

button:hover {
    background-color: #111827;
}

#previewimage {
    margin-top: 1rem;
    width: 200px;
    height: 200px;
    object-fit: cover;
    border-radius: 10px;
    display: none;
    border: 1px solid #D1D5DB;
}

.alert-danger {
    background-color: #FECACA;
    color: #B91C1C;
    border-radius: 10px;
    padding: 1rem;
    margin-bottom: 1rem;
}

.alert-danger ul {
    margin: 0;
    padding-left: 1.25rem;
}
</style>

<script src="<?php echo e(asset('viewjs/createmenu.js')); ?>"></script>

<div class="container-centered">
    <div class="card-box">
        <h2>Create Donation</h2>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(route('createdonation')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <label for="name">Donation Name</label>
            <input type="text" name="name" id="name" placeholder="Enter donation name">

            <label for="description">Description</label>
            <textarea name="description" id="description" rows="4" placeholder="Enter donation description"></textarea>

            <label for="price">Price per Unit</label>
            <input type="number" name="price" id="price" placeholder="Enter price per unit">

            <label for="count">Available Stock</label>
            <input type="number" name="count" id="count" placeholder="Enter available stock">

            <label for="image">Upload an Image</label>
            <input type="file" name="image" id="imageupload" onchange="imagepreview(this,'previewimage')">

            <img id="previewimage" src="#" alt="Preview Image">

            <button type="submit">Create Donation</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.headandfoot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/cpm24/Downloads/SoftwareEngineeringProject-master 6/resources/views/createdonationview.blade.php ENDPATH**/ ?>