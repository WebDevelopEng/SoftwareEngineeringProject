<?php $__env->startSection('title'); ?>
Create a Recipe
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    body {
        background-color: #ffe6c7;
        font-family: 'Montserrat', sans-serif;
    }

    .form-container {
        width: 60%;
        margin: 40px auto;
        background: white;
        border-radius: 12px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        padding: 30px 40px;
    }

    .form-container h3 {
        text-align: center;
        color: #2c3e50;
        margin-bottom: 30px;
    }

    label {
        font-weight: bold;
        margin-top: 10px;
    }

    .form-control,
    .form-select,
    input[type="text"] {
        margin-top: 5px;
        margin-bottom: 15px;
        width: 100%;
        padding: 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
    }

    .form-check-group {
        display: flex;
        gap: 20px;
        align-items: center;
        margin-bottom: 20px;
    }

    .form-check {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .form-check-input {
        width: 18px;
        height: 18px;
        accent-color: #e07b39;
    }

    .btn-submit {
        background-color: #e07b39;
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 6px;
        font-weight: bold;
        width: 100%;
        transition: background-color 0.3s ease;
        margin-top: 20px;
    }

    .btn-submit:hover {
        background-color: #cf6c2c;
    }

    .preview {
        width: 50%;
        margin-top: 15px;
        display: none;
        border-radius: 8px;
    }

    .alert-danger {
        margin-top: 20px;
    }
</style>

<script src="<?php echo e(asset('viewjs/createmenu.js')); ?>"></script>

<div class="form-container">
    <h3>Enter Recipe Information</h3>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul style="margin-bottom: 0;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('recipecreation')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <label for="name">Recipe Name:</label>
        <input type="text" id="name" name="name" class="form-control" placeholder="Input the name of your recipe">

        <label for="category">Food Category:</label>
        <select name="category" id="category" class="form-select">
            <option value="Seafood">Seafood</option>
            <option value="Noodles">Noodles</option>
            <option value="Rice">Rice</option>
            <option value="Snacks">Snacks</option>
        </select>

        <label for="description">Description:</label>
        <textarea id="description" name="description" class="form-control" rows="4" placeholder="Enter your description"></textarea>

        <label for="ingredients">Ingredients:</label>
        <textarea id="ingredients" name="ingredients" class="form-control" rows="4" placeholder="Enter your ingredients"></textarea>

        <label for="premium">Premium Setup:</label>
        <div class="form-check-group">
            <div class="form-check">
                <input class="form-check-input" type="radio" name="premium" id="radio1" value="1">
                <label class="form-check-label" for="radio1">Premium</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="premium" id="radio2" value="0">
                <label class="form-check-label" for="radio2">Non Premium</label>
            </div>
        </div>

        <label for="imageupload">Upload Image:</label>
        <input type="file" accept="image/*" onchange="imagepreview(this,'previewimage')" name="image" id="imageupload" class="form-control">
        <img class="preview" src="" id="previewimage">

        <button type="submit" class="btn-submit">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.headandfoot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/cpm24/Downloads/SoftwareEngineeringProject-master 6 3/resources/views/createmenu.blade.php ENDPATH**/ ?>