<?php $__env->startSection('title'); ?>
    Menu Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('viewcss/menudashboard.css')); ?>">
<script src="<?php echo e(asset('viewjs/menudashboard.js')); ?>"></script>

<div id="recipeCarousel" class="carousel slide" data-bs-ride="carousel" style="margin: 30px auto 50px; max-width: 80%;">
    <div class="carousel-inner">
        <div class="carousel-item active">
                    <div class="profile-card">
                        <img
                            src="<?php echo e(asset('photo/salmonbeurreblanc.jpg')); ?>"
                            alt="Salmon Beurre Blanc"
                            class="carousel-img"
                        >
                    </div>
                </div>
        <?php $carouselRecipes = $collection->take(3); ?>
        <?php $__currentLoopData = $carouselRecipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $imageurl = "/storage/recipeimages/" . $recipe->image;
                $recipeurl = "/viewrecipe/" . $recipe->RecipeID;
            ?>
            <div class="carousel-item <?php if($index == 0): ?> active <?php endif; ?>">
                <img src="<?php echo e($imageurl); ?>" class="d-block w-100" style="height: 350px; object-fit: cover; border-radius:10px;" alt="Recipe image">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-3">
                    <h5><?php echo e($recipe->Name); ?></h5>
                    <p><?php echo e(Str::limit($recipe->Description, 100)); ?></p>
                    <a href="<?php echo e($recipeurl); ?>" class="btn btn-warning text-dark fw-bold">View Recipe</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<section class="search-section">
  <h3 class="search-title">Recipe Search</h3>

  <div class="search-bar-wrapper">
    <form method="POST" action="/menudashboard" class="input-group">
      <?php echo csrf_field(); ?>
      <input 
        type="text" 
        name="search" 
        id="searchbar" 
        class="form-control" 
        placeholder="Search recipes…"
      >
      <button class="btn btn-dark" type="submit">
        <i class="fa fa-search"></i>
      </button>
    </form>
  </div>
</section>

<div class="dashboard-section mt-4">
    <h2><?php echo e(isset($state) ? 'Search' : 'Top Picks'); ?></h2>
    <div class="cards-wrapper d-flex flex-wrap gap-4 justify-content-center mt-3">
        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $imageurl = "/storage/recipeimages/" . $recipe->image;
                $recipeurl = "/viewrecipe/" . $recipe->RecipeID;
            ?>
            <div class="card" style="width: 18rem; min-height: 300px;">
                <img src="<?php echo e($imageurl); ?>" alt="<?php echo e($recipe->Name); ?>" style="width:100%; height:150px; object-fit: cover;">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($recipe->Name); ?></h5>
                    <div class="btn btn-info mb-2"><?php echo e($recipe->category); ?></div>
                    <p class="card-text"><?php echo e(Str::limit($recipe->Description, 25)); ?></p>
                </div>
                <div class="px-3 pb-3">
                    <?php
                        $isLocked = ($membership == 0 && $recipe->premium == 1 && null == Session::get('restaurant')) ||
                                    (null !== Session::get('restaurant') && Session::get('restaurant')->id !== $recipe->restaurant_id);
                    ?>
                    <?php if($isLocked): ?>
                        <a class="btn btn-secondary disabled card-link" href="<?php echo e($recipeurl); ?>">
                            <i class="fa-solid fa-lock"></i> Recipe locked
                        </a>
                    <?php else: ?>
                        <a class="btn btn-dark card-link" href="<?php echo e($recipeurl); ?>">
                            View recipe <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<div class="d-flex justify-content-center mt-4">
    <?php echo e($collection->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.headandfoot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/cpm24/Downloads/SoftwareEngineeringProject-master 6 3/resources/views/menudashboard.blade.php ENDPATH**/ ?>