<?php $__env->startSection('title'); ?>
Registration
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('viewjs/registration.js')); ?>"></script>
<link href="<?php echo e(asset('viewcss/login.css')); ?>" rel="stylesheet">
<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
<body style="background-color: rgba(255,235,205,1)">
<div class="login-card">
    <form method="post" action="<?php echo e(route('registacc')); ?>" id="form"  class="login-form">
        <?php echo csrf_field(); ?>
        <h3 class="login-title" style="margin:0">Welcome to DonaCook!</h3>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="login-tabs">
            <button type="button" class="login-tab" onclick="registtype('userselection')" id="userselection" >User</button>
            <button type="button" class="login-tab" onclick="registtype('restoselection')" id="restoselection" >Restaurant</button>
        </div>
        <div class="form-group">
            <label for="username">Enter your username:</label>
            <input type="text" class="form-control" id="username" name="name">
        </div>
        <div class="form-group">
            <label for="email"> Enter your email:</label>
            <input type="email" class="form-control" id="email" name="email">
        </div>
        <div class="form-group">
            <label for="password"  id="password"> Enter your password:</label>
            <input type="password" class="form-control" id="password" name="password">
        </div>
        <div class="form-group">
            <div id="userselectionarea"> 
            <label for="dob"> Enter your date of birth:</label>
            <input type="date" class="form-control" id="dob" name="dob">
        </div>

        <div class="form-group">
            <div id="restoselectionarea" style="display:none">
            <label for="location"> Enter your location: </label>
            <textarea id="location" name="location" row="4" column="50"></textarea>
            </div>
        </div>

        <input type="text" style="display:none" name="hidden" id="hidden" value="userselection">
        <button type="submit" class="btn-submit">Register</button>
    </form>
</div>
</div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.headandfoot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Binus 2\Sems 6\SoftEn\SoftwareEngineeringProject\SoftwareEngineeringProject-master\resources\views/registpage.blade.php ENDPATH**/ ?>