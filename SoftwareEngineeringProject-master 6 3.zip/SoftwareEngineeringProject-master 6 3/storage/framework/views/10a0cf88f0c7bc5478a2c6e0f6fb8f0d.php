<?php $__env->startSection('title'); ?>
    Recipe
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(isset($recipe)): ?>
    <?php
        $imageurl = '/storage/recipeimages/' . $recipe->image;
    ?>
    <?php if($ad !== null): ?>
        <?php
            $adurl = '/storage/advertimages/' . $ad->image;
        ?>
        <script src="<?php echo e(asset('viewjs/menupage.js')); ?>"></script>
        <!-- Popup Advertisement Overlay -->
        <div id="background-fade">
            <button type="button" onclick="closewindow()">
                <i class="fa fa-times"></i>
            </button>
        </div>
        <div id="ad">
            <img src="<?php echo e($adurl); ?>" alt="Advertisement">
        </div>
    <?php endif; ?>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: blanchedalmond;
            color: #2c3e50;
            line-height: 1.6;
        }
        #background-fade {
            position: absolute;
            top: 0; left: 0;
            width: 100%;
            height: 100%;
            background-color: #2c3e50;
            opacity: 0.5;
            z-index: 2;
            display: block;
            padding: 10px;
        }
        #background-fade button {
            background-color: #f1c40f;
            border: none;
            color: #2c3e50;
            font-size: 1.5em;
            cursor: pointer;
        }
        #ad {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            border: 2px solid #2c3e50;
            border-radius: 8px;
            z-index: 3;
            padding: 20px;
        }
        #ad img {
            max-height: 500px;
            object-fit: fill;
        }
        /* Recipe Overview Container */
        .menuoverview {
            border: 2px solid #2c3e50;
            padding-top: 1%;
            margin: 20px auto;
            max-width: 800px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(44, 62, 80, 0.1);
        }
        .menuoverview .title {
            text-align: center;
            font-size: 2rem;
            margin-bottom: 2%;
            color: #2c3e50;
            border-bottom: 2px solid #f1c40f;
            padding-bottom: 10px;
        }
        /* Food Image Container */
        .foodimagecontainer {
            position: relative;
            border-style: solid;
            border-color: #2c3e50;
            border-width: 2px 0;
            overflow: hidden;
            height: 300px;
        }
        .foodimagecontainer img:first-child {
            position: absolute;
            width: 100%;
            height: 100%;
            object-fit: fill;
            filter: blur(10px) grayscale(100%);
        }
        .foodimagecontainer img:last-child {
            position: relative;
            width: 100%;
            height: 100%;
            object-fit: contain;
            border: none;
        }
        .tablerowcontainer {
            padding: 20px;
        }
        .tablerowcontainer h5 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        .halfwidth {
            width: 50%;
            display: inline-block;
            vertical-align: middle;
            padding: 10px;
        }
        .halfwidth img {
            width: 50px;
            height: 50px;
            border-radius: 25px;
            object-fit: cover;
        }
        .btn {
            display: inline-block;
            padding: 8px 16px;
            margin: 10px 0;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 600;
        }
        .btn.btn-info {
            background-color: #f1c40f;
            color: #2c3e50;
        }

        @media (max-width: 768px) {
            .halfwidth {
                width: 100%;
                text-align: center;
            }
            .foodimagecontainer {
                height: 200px;
            }
        }
    </style>

    <div class="menuoverview">
        <h3 class="title"><?php echo e($recipe->Name); ?></h3>
        <div class="foodimagecontainer">
            <img src="<?php echo e($imageurl); ?>" alt="Recipe Background">
            <img src="<?php echo e($imageurl); ?>" alt="Recipe Image">
        </div>
        <div class="tablerowcontainer" style="display: flex; flex-wrap: wrap;">
            <div class="halfwidth">
                <h5>Restaurant Author</h5>
            </div>
            <div class="halfwidth" style="border-left: 2px solid #2c3e50;">
                <?php if($restaurant->image == null): ?>
                    <img src="<?php echo e(asset('profileimage/defaultimage.jpg')); ?>" alt="Default Profile">
                <?php else: ?>
                    <?php
                        $newimageurl = '/storage/profileimages/' . $restaurant->image;
                    ?>
                    <img src="<?php echo e($newimageurl); ?>" alt="Restaurant Profile">
                <?php endif; ?>
                <?php echo e($restaurant->restaurantName); ?>

            </div>
            <div style="width:100%; padding: 10px 0;">
                <div class="btn btn-info"><?php echo e($recipe->category); ?></div>
            </div>
        </div>
        <div class="tablerowcontainer" style="border-top: 2px solid #2c3e50;">
            <div style="text-align: left; width: 80%; margin: auto;">
                <h5>Ingredients:</h5>
            </div>
            <div style="text-align: left; width: 80%; margin: auto;">
                <?php echo e($recipe->Ingredients); ?>

            </div>
        </div>
        <div class="tablerowcontainer">
            <div style="text-align: left; width: 80%; margin: auto;">
                <h5>Description:</h5>
            </div>
            <div style="text-align: left; width: 80%; margin: auto;">
                <?php echo e($recipe->Description); ?>

            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.headandfoot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/cpm24/Downloads/SoftwareEngineeringProject-master 6 3/resources/views/menupage.blade.php ENDPATH**/ ?>