@extends('templates.headandfoot')
@section('title')
My Recipes
@endsection

@section('content')
<div style="background-color: #ffe5b4; min-height: 100vh; padding: 2% 0;">
    <div style="width: 80%; margin: auto; background-color: white; border-radius: 15px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); padding: 2%;">
        <h3 style="text-align: center; margin-bottom: 30px;">My Recipes</h3>

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        @if(isset($collection) && count($collection) > 0)
            @foreach($collection as $recipe)
                @php
                    $img = $recipe->image ? '/storage/recipeimages/' . $recipe->image : null;
                @endphp
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; padding: 15px; border: 1px solid #ccc; border-radius: 10px;">
                    <div style="display: flex; align-items: center;">
                        @if($img)
                            <img src="{{ $img }}" alt="Recipe Image" style="width: 100px; height: 100px; object-fit: cover; border-radius: 10px; margin-right: 20px;">
                        @endif
                        <div>
                            <h5 style="margin: 0;">{{ $recipe->name }}</h5>
                            <p style="margin: 0;">{{ \Illuminate\Support\Str::limit($recipe->description, 50) }}</p>
                        </div>
                    </div>
                    <div>
                        <a class="btn btn-info" href="{{ route('editrecipe', ['id' => $recipe->id]) }}" style="margin-right: 10px;">Edit</a>
                        <a class="btn btn-danger" href="{{ route('deleterecipe', ['id' => $recipe->id]) }}">Delete</a>
                    </div>
                </div>
            @endforeach

            <div style="text-align: center; margin-top: 20px;">
                {{ $collection->links() }}
            </div>
        @else
            <p style="text-align: center;">You haven't created any recipes yet.</p>
        @endif
    </div>
</div>
@endsection
